# this is a program that allows the user to roll any die required for Dungeons and Dragons -R
# import random and tkinter are required for random number decisions and GUI support (respectively) -R
import random
from tkinter import *
from tkinter import PhotoImage
import tkinter as tk

# win creates the window with tkinter, geometry creates the size of the window, and title names the window -R
win = Tk()
win.geometry("750x425")
win.title('5e Dice')

# this loads the tile image in the corner of the screen and creates a label to display it in -R
image = PhotoImage(file="")
image_label = tk.Label(win, image=image)
image_label.pack()

# this image is supposed to display on the right to cut the dead space on the right side of the screen -R
image2 = PhotoImage(file="")
image2_label = tk.Label(win, image=image)
image2_label.pack()

# since i repeat the following few modules for each die rolled, I am only going to comment here for what each one actually does. This essentially creates a system for a day that creates a label in the GUI
# which will present a random number depending on what is set (minimum of 1, maximum of die num ala; 6 for d6, 8 for d8, and so on), and then when the button for each label is clicked it will print
# the randomly rolled die to its respective label -R
#this rolls a d4 -R
def rollFour():
    labelFour["text"] = str(random.randint(1,4)) # this is the random die roll module as mentioned earlier, this is used in every single roll(num) variable including rollFour, obiviously -R
FourButton = Button(win, width=20, bg='light yellow', fg='blue', command= rollFour, bd=3, relief=RAISED, activebackground='white', text='Roll a d4')
FourButton.pack()
labelFour = Label(win, width=20, bg='sky blue', fg='purple')
labelFour.pack()

# this rolls a d6 -R
def rollSix():
    labelSix["text"] = str(random.randint(1,6))
sixButton = Button(win, width=20, bg='light yellow', fg='blue', command= rollSix, bd=3, relief=RAISED, activebackground='white', text='Roll a d6')
sixButton.pack()
labelSix = Label(win, width=20, bg='sky blue', fg='purple')
labelSix.pack()

# this rolls a d8 -R
def roll8():
    labelEight["text"] = str(random.randint(1,8))
eightButton = Button(win, width=20, bg='light yellow', fg='blue', command= roll8, bd=3, relief=RAISED, activebackground='white', text='Roll a d8')
eightButton.pack()
labelEight = Label(win, width=20, bg='sky blue', fg='purple')
labelEight.pack()

# this rolls a d10 -R
def roll10():
    labelTen["text"] = str(random.randint(1,10))
tenButton = Button(win, width=20, bg='light yellow', fg='blue', command= roll10, bd=3, relief=RAISED, activebackground='white', text='Roll a d10')
tenButton.pack()
labelTen = Label(win, width=20, bg='sky blue', fg='purple')
labelTen.pack()

# this rolls a d12 -R
def roll12():
    labelTwelve["text"] = str(random.randint(1,12))
twelveButton = Button(win, width=20, bg='light yellow', fg='blue', command= roll12, bd=3, relief=RAISED, activebackground='white', text='Roll a d12')
twelveButton.pack()
labelTwelve = Label(win, width=20, bg='sky blue', fg='purple')
labelTwelve.pack()

# this rolls a d20 -R
def roll20():
    labelTwenty["text"] = str(random.randint(1,20))
twentyButton = Button(win, width=20, bg='light yellow', fg='blue', command= roll20, bd=3, relief=RAISED, activebackground='white', text='Roll a d20')
twentyButton.pack()
labelTwenty = Label(win, width=20, bg='sky blue', fg='purple')
labelTwenty.pack()

# this rolls a d100 -R
def roll100():
    labelHundred["text"] = str(random.randint(1,100))
HundredButton = Button(win, width=20, bg='light yellow', fg='blue', command= roll100, bd=3, relief=RAISED, activebackground='white', text='Roll a d100')
HundredButton.pack()
labelHundred= Label(win, width=20, bg='sky blue', fg='purple')
labelHundred.pack()

# this essentially sets up a system that allows the user to close the window whenever they are done using the application and displays at the bottom of the screen -R
def closeWindow():
    win.destroy()
closeButton = Button(win, text="Close Window", command=closeWindow)
closeButton.pack(pady=20) 

# this is required for the existence of the window screen -R
win.mainloop()